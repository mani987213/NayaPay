import Header from "@/components/Header";
import WalletCard from "@/components/WalletCard";
import FindFriendsCard from "@/components/FindFriendsCard";
import PaymentOptionsGrid from "@/components/PaymentOptionsGrid";
import BottomNavigation from "@/components/BottomNavigation";
import TransactionHistory from "@/components/TransactionHistory";
import ExpenseChart from "@/components/ExpenseChart";
import BannerPromotion from "@/components/BannerPromotion";
import UserProfile from "@/components/UserProfile";
import { Home as HomeIcon, Wallet, CreditCard, BarChart3, Settings, Bell, User, Search, Headphones } from "lucide-react";
import { NayaPayLogo } from "@/lib/icons";
import { useState } from "react";
import NotificationCenter from "@/components/NotificationCenter";

export default function Home() {
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isUserProfileOpen, setIsUserProfileOpen] = useState(false);
  
  return (
    <div className="flex justify-center">
      {/* Web version container with sidebar */}
      <div className="hidden md:flex bg-gray-100 min-h-screen w-full max-w-screen-xl">
        {/* Sidebar */}
        <div className="w-64 bg-white border-r border-gray-200 py-6 hidden lg:block">
          <div className="px-6 pb-6 border-b border-gray-200">
            <h2 className="text-2xl font-bold text-[hsl(var(--naya-dark))] flex items-center">
              <span className="text-[hsl(var(--naya-orange-start))]">NAYA</span>
              <span className="text-[hsl(var(--naya-orange-end))]">PAY</span>
              <span className="bg-green-500 text-white text-xs rounded px-1 ml-1 flex items-center justify-center h-5">BETA</span>
            </h2>
          </div>
          
          <nav className="mt-6 px-4">
            <ul className="space-y-2">
              <li>
                <a href="#" className="flex items-center px-4 py-3 text-[hsl(var(--naya-green))] bg-green-50 rounded-lg">
                  <HomeIcon className="h-5 w-5 mr-3" />
                  <span className="font-medium">Home</span>
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center px-4 py-3 text-gray-600 hover:bg-gray-50 rounded-lg">
                  <Wallet className="h-5 w-5 mr-3" />
                  <span>My Wallet</span>
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center px-4 py-3 text-gray-600 hover:bg-gray-50 rounded-lg">
                  <CreditCard className="h-5 w-5 mr-3" />
                  <span>Cards</span>
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center px-4 py-3 text-gray-600 hover:bg-gray-50 rounded-lg">
                  <BarChart3 className="h-5 w-5 mr-3" />
                  <span>Analytics</span>
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center px-4 py-3 text-gray-600 hover:bg-gray-50 rounded-lg">
                  <Settings className="h-5 w-5 mr-3" />
                  <span>Settings</span>
                </a>
              </li>
            </ul>
          </nav>
          
          <div className="mt-auto px-6 pt-6 border-t border-gray-200">
            <div className="bg-blue-50 p-4 rounded-lg mt-20">
              <h3 className="text-sm font-medium text-blue-800 mb-2">Need Help?</h3>
              <p className="text-xs text-blue-600 mb-3">Our support team is available 24/7 to assist you.</p>
              <button className="w-full bg-white text-blue-600 border border-blue-200 py-2 px-3 rounded-md text-sm font-medium hover:bg-blue-50">
                Contact Support
              </button>
            </div>
          </div>
        </div>
        
        {/* Main content for web */}
        <div className="flex-1 py-6 px-6 overflow-auto">
          {/* Header for desktop */}
          <div className="max-w-6xl mx-auto mb-8">
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-2xl font-bold text-[hsl(var(--naya-dark))]">Welcome to NayaPay</h1>
              
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search..."
                    className="py-2 pl-10 pr-4 rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[hsl(var(--naya-green))] focus:border-transparent"
                  />
                  <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
                
                <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full relative">
                  <Headphones className="h-5 w-5" />
                </button>
                
                <button 
                  className="p-2 text-gray-600 hover:bg-gray-100 rounded-full relative" 
                  onClick={() => setIsNotificationOpen(true)}
                >
                  <Bell className="h-5 w-5" />
                  <span className="absolute -top-1 -right-1 bg-[hsl(var(--naya-green))] text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">1</span>
                </button>
                
                <button 
                  className="p-2 text-gray-600 hover:bg-gray-100 rounded-full"
                  onClick={() => setIsUserProfileOpen(true)}
                >
                  <User className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            <BannerPromotion />
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
              <div className="lg:col-span-2">
                <WalletCard />
                <ExpenseChart />
              </div>
              
              <div className="lg:col-span-1">
                <FindFriendsCard />
                <TransactionHistory />
              </div>
            </div>
            
            <PaymentOptionsGrid />
          </div>
        </div>
      </div>
      
      {/* Mobile version */}
      <div className="md:hidden max-w-md mx-auto bg-white min-h-screen shadow-lg flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-auto pb-16">
          <WalletCard />
          <ExpenseChart />
          <TransactionHistory />
          <PaymentOptionsGrid />
        </main>
        
        <BottomNavigation />
      </div>
      
      {/* Shared components */}
      <NotificationCenter isOpen={isNotificationOpen} setIsOpen={setIsNotificationOpen} />
      <UserProfile isOpen={isUserProfileOpen} setIsOpen={setIsUserProfileOpen} />
    </div>
  );
}
