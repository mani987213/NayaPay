import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface QRCodeModalProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

export default function QRCodeModal({ isOpen, setIsOpen }: QRCodeModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Quick Pay</DialogTitle>
          <DialogDescription>
            Scan this QR code to pay or share it with others.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col items-center justify-center py-6">
          <div className="bg-white p-3 border rounded-lg mb-4">
            <svg
              width="200"
              height="200"
              viewBox="0 0 200 200"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="w-full h-full"
            >
              {/* QR Code SVG pattern - this is a simplified QR code representation */}
              <rect width="200" height="200" fill="white" />
              <g fill="black">
                {/* Frame squares */}
                <rect x="10" y="10" width="30" height="30" />
                <rect x="20" y="20" width="10" height="10" fill="white" />
                
                <rect x="160" y="10" width="30" height="30" />
                <rect x="170" y="20" width="10" height="10" fill="white" />
                
                <rect x="10" y="160" width="30" height="30" />
                <rect x="20" y="170" width="10" height="10" fill="white" />
                
                {/* QR code data modules - simplified pattern */}
                <rect x="55" y="10" width="10" height="10" />
                <rect x="75" y="10" width="10" height="10" />
                <rect x="95" y="10" width="10" height="10" />
                <rect x="115" y="10" width="10" height="10" />
                <rect x="135" y="10" width="10" height="10" />
                
                <rect x="10" y="55" width="10" height="10" />
                <rect x="50" y="55" width="10" height="10" />
                <rect x="90" y="55" width="10" height="10" />
                <rect x="130" y="55" width="10" height="10" />
                <rect x="180" y="55" width="10" height="10" />
                
                <rect x="10" y="75" width="10" height="10" />
                <rect x="30" y="75" width="10" height="10" />
                <rect x="70" y="75" width="10" height="10" />
                <rect x="110" y="75" width="10" height="10" />
                <rect x="150" y="75" width="10" height="10" />
                <rect x="180" y="75" width="10" height="10" />
                
                <rect x="10" y="95" width="10" height="10" />
                <rect x="50" y="95" width="10" height="10" />
                <rect x="110" y="95" width="10" height="10" />
                <rect x="150" y="95" width="10" height="10" />
                <rect x="180" y="95" width="10" height="10" />
                
                <rect x="10" y="115" width="10" height="10" />
                <rect x="30" y="115" width="10" height="10" />
                <rect x="50" y="115" width="10" height="10" />
                <rect x="70" y="115" width="10" height="10" />
                <rect x="90" y="115" width="10" height="10" />
                <rect x="110" y="115" width="10" height="10" />
                <rect x="130" y="115" width="10" height="10" />
                <rect x="150" y="115" width="10" height="10" />
                <rect x="180" y="115" width="10" height="10" />
                
                <rect x="10" y="135" width="10" height="10" />
                <rect x="50" y="135" width="10" height="10" />
                <rect x="90" y="135" width="10" height="10" />
                <rect x="130" y="135" width="10" height="10" />
                <rect x="180" y="135" width="10" height="10" />
                
                <rect x="55" y="180" width="10" height="10" />
                <rect x="75" y="180" width="10" height="10" />
                <rect x="95" y="180" width="10" height="10" />
                <rect x="115" y="180" width="10" height="10" />
                <rect x="135" y="180" width="10" height="10" />
              </g>
              
              {/* NayaPay logo in the center */}
              <rect x="70" y="70" width="60" height="60" fill="white" />
              <circle cx="100" cy="100" r="25" fill="#22C55E" />
              <path d="M90 95L100 105L115 90" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <p className="text-lg font-semibold mb-1">NayaPay Wallet</p>
          <p className="text-sm text-gray-500 mb-4">Rs.1,124,800</p>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1">Share</Button>
            <Button className="flex-1 bg-[hsl(var(--naya-green))]">Save Image</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}