import { 
  QrCode, User, Store, FileText, Receipt, 
  HandCoins
} from "lucide-react";
import { useState } from "react";
import QRCodeModal from "./QRCodeModal";

interface PaymentOptionProps {
  icon: React.ReactNode;
  title: string;
  onClick?: () => void;
}

function PaymentOption({ icon, title, onClick }: PaymentOptionProps) {
  return (
    <div className="flex flex-col items-center" onClick={onClick}>
      <div className="bg-white p-3 border border-gray-200 rounded-md mb-2 w-14 h-14 flex items-center justify-center cursor-pointer">
        {icon}
      </div>
      <span className="text-xs text-center text-[hsl(var(--naya-dark))]">{title}</span>
    </div>
  );
}

export default function PaymentOptionsGrid() {
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);
  
  const handleQuickPayClick = () => {
    setIsQRModalOpen(true);
  };

  const paymentOptions = [
    { icon: <QrCode className="text-[hsl(var(--naya-dark))] h-5 w-5" />, title: "Quick Pay", onClick: handleQuickPayClick },
    { icon: <User className="text-[hsl(var(--naya-dark))] h-5 w-5" />, title: "Pay Contact" },
    { icon: <Store className="text-[hsl(var(--naya-dark))] h-5 w-5" />, title: "Discover Merchants" },
    { icon: <FileText className="text-[hsl(var(--naya-dark))] h-5 w-5" />, title: "Bills" },
    { icon: <Receipt className="text-[hsl(var(--naya-dark))] h-5 w-5" />, title: "Bill Split" },
    { icon: <HandCoins className="text-[hsl(var(--naya-dark))] h-5 w-5" />, title: "Chip In" }
  ];

  return (
    <div className="bg-white m-4 rounded-xl shadow-md overflow-hidden">
      <div className="p-4">
        <h2 className="text-[hsl(var(--naya-dark))] text-lg font-medium mb-4">Payment Services</h2>
        <div className="grid grid-cols-3 gap-6">
          {paymentOptions.map((option, index) => (
            <PaymentOption 
              key={index} 
              icon={option.icon} 
              title={option.title} 
              onClick={option.onClick}
            />
          ))}
        </div>
      </div>
      
      <QRCodeModal isOpen={isQRModalOpen} setIsOpen={setIsQRModalOpen} />
    </div>
  );
}
