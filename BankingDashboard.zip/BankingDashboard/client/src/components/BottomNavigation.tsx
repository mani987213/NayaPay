import { useState } from "react";
import { Home, MessageSquare, CreditCard, ArrowRightLeft } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function BottomNavigation() {
  const [location] = useLocation();
  
  // Determine active tab based on current location
  const isActive = (path: string) => location === path;
  
  const navItems = [
    { path: "/", icon: <Home />, label: "Home" },
    { path: "/chat", icon: <MessageSquare />, label: "Chat" },
    { path: "/cards", icon: <CreditCard />, label: "Cards" },
    { path: "/payments", icon: <ArrowRightLeft />, label: "Payments" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-between max-w-md mx-auto shadow-lg">
      {navItems.map(({ path, icon, label }) => (
        <Link key={path} href={path}>
          <div className={`flex flex-col items-center justify-center p-3 flex-1 cursor-pointer ${
            isActive(path) ? "text-[hsl(var(--naya-green))]" : "text-[hsl(var(--naya-text-gray))]"
          }`}>
            <div className="text-lg">
              {icon}
            </div>
            <span className="text-xs mt-1">{label}</span>
          </div>
        </Link>
      ))}
    </nav>
  );
}
