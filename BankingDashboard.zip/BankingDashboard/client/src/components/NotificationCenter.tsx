import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Bell, X, Gift, Clock, CreditCard, Tag } from "lucide-react";
import { useState } from "react";

interface NotificationProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

interface Notification {
  id: number;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: "promo" | "transaction" | "reminder" | "alert";
}

export default function NotificationCenter({ isOpen, setIsOpen }: NotificationProps) {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      title: "Special Discount",
      message: "Get 20% cashback on your next StormFiber bill payment!",
      time: "10 mins ago",
      read: false,
      type: "promo"
    },
    {
      id: 2,
      title: "Money Received",
      message: "You've received Rs.5,000 from Maria Khan.",
      time: "2 hours ago",
      read: false,
      type: "transaction"
    },
    {
      id: 3,
      title: "Bill Reminder",
      message: "Your K-Electric bill is due in 3 days.",
      time: "Yesterday",
      read: true,
      type: "reminder"
    },
    {
      id: 4,
      title: "Successful Payment",
      message: "Your payment of Rs.3,500 to StormFiber was successful.",
      time: "2 days ago",
      read: true,
      type: "transaction"
    },
    {
      id: 5,
      title: "Security Alert",
      message: "Your NayaPay account was accessed from a new device.",
      time: "3 days ago",
      read: true,
      type: "alert"
    }
  ]);
  
  const markAllAsRead = () => {
    setNotifications(notifications.map(notif => ({ ...notif, read: true })));
  };
  
  const getNotificationIcon = (type: string) => {
    switch(type) {
      case "promo":
        return <Tag className="h-5 w-5 text-purple-500" />;
      case "transaction":
        return <CreditCard className="h-5 w-5 text-green-500" />;
      case "reminder":
        return <Clock className="h-5 w-5 text-orange-500" />;
      case "alert":
        return <Bell className="h-5 w-5 text-red-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0 pb-2 border-b">
          <div className="flex justify-between items-center">
            <DialogTitle>Notifications</DialogTitle>
            <button 
              onClick={markAllAsRead}
              className="text-sm text-[hsl(var(--naya-green))] font-medium"
            >
              Mark all as read
            </button>
          </div>
        </DialogHeader>
        
        <div className="overflow-y-auto flex-1">
          {notifications.length === 0 ? (
            <div className="text-center py-10">
              <Bell className="mx-auto h-12 w-12 text-gray-300 mb-4" />
              <p className="text-gray-500">No notifications yet</p>
            </div>
          ) : (
            <ul className="divide-y divide-gray-100">
              {notifications.map((notification) => (
                <li key={notification.id} className={`p-4 hover:bg-gray-50 cursor-pointer ${!notification.read ? 'bg-green-50' : ''}`}>
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-1">
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="ml-3 flex-1">
                      <div className="flex justify-between">
                        <p className={`text-sm font-medium ${!notification.read ? 'text-[hsl(var(--naya-dark))]' : 'text-gray-600'}`}>
                          {notification.title}
                        </p>
                        <p className="text-xs text-gray-400">{notification.time}</p>
                      </div>
                      <p className="text-sm text-gray-500">{notification.message}</p>
                    </div>
                    {!notification.read && (
                      <span className="h-2 w-2 bg-[hsl(var(--naya-green))] rounded-full mt-2"></span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
        
        <div className="mt-4 flex-shrink-0 pt-2 border-t">
          <button 
            className="w-full text-center text-[hsl(var(--naya-green))] text-sm font-medium py-2"
          >
            View All Notifications
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}