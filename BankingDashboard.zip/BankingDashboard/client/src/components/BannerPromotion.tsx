import { ArrowRight } from "lucide-react";

export default function BannerPromotion() {
  return (
    <div className="overflow-hidden rounded-xl shadow-md m-4 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-indigo-600 opacity-90"></div>
      
      <div className="relative p-6 flex flex-col md:flex-row items-center">
        <div className="flex-1 text-white mb-4 md:mb-0">
          <h2 className="text-xl font-bold mb-2">Refer & Earn Rewards</h2>
          <p className="text-white/80 text-sm mb-4">
            Invite your friends to NayaPay and get Rs.500 for each successful referral!
          </p>
          <button className="flex items-center bg-white text-indigo-600 px-4 py-2 rounded-lg text-sm font-medium hover:bg-opacity-90 transition-colors">
            Invite Friends
            <ArrowRight className="h-4 w-4 ml-2" />
          </button>
        </div>
        
        <div className="w-24 h-24 md:w-32 md:h-32 flex items-center justify-center">
          <div className="relative">
            {/* Gift box illustration */}
            <div className="w-16 h-16 md:w-20 md:h-20 bg-white rounded-lg relative overflow-hidden shadow-lg">
              <div className="absolute inset-x-0 top-0 h-1/2 bg-pink-500"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl md:text-3xl">🎁</span>
              </div>
              <div className="absolute left-0 right-0 top-[40%] h-2 bg-pink-600"></div>
            </div>
            {/* Flying coins effect */}
            <div className="absolute -top-3 -right-3 h-6 w-6 bg-yellow-400 rounded-full flex items-center justify-center text-yellow-800 text-xs font-bold">
              ₹
            </div>
            <div className="absolute -bottom-2 -left-2 h-5 w-5 bg-yellow-400 rounded-full flex items-center justify-center text-yellow-800 text-xs font-bold">
              ₹
            </div>
          </div>
        </div>
      </div>
      
      {/* Bottom wave effect */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="w-full h-12 md:h-16 text-white opacity-20">
          <path fill="currentColor" d="M0,224L60,213.3C120,203,240,181,360,181.3C480,181,600,203,720,213.3C840,224,960,224,1080,208C1200,192,1320,160,1380,144L1440,128L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"></path>
        </svg>
      </div>
    </div>
  );
}