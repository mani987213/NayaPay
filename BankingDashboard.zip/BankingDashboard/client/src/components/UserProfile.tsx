import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { User, MapPin, Mail, Phone, Shield, ChevronRight, CreditCard, Key, LogOut } from "lucide-react";

interface UserProfileProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

export default function UserProfile({ isOpen, setIsOpen }: UserProfileProps) {
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-auto">
        <DialogHeader className="text-center pb-4 border-b">
          <div className="flex flex-col items-center">
            <div className="h-20 w-20 rounded-full bg-gray-200 flex items-center justify-center mb-3">
              <User className="h-10 w-10 text-gray-500" />
            </div>
            <DialogTitle className="text-xl">Fatima Ahmed</DialogTitle>
            <p className="text-gray-500 text-sm flex items-center mt-1">
              <MapPin className="h-3 w-3 mr-1" /> Karachi, Pakistan
            </p>
          </div>
        </DialogHeader>
        
        <div className="py-4">
          <div className="space-y-4">
            {/* Contact Info */}
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-2">Contact Information</h3>
              <div className="space-y-3">
                <div className="flex items-center">
                  <Mail className="h-4 w-4 text-gray-400 mr-3" />
                  <span className="text-sm">fatima.ahmed@example.com</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 text-gray-400 mr-3" />
                  <span className="text-sm">+92 300 1234567</span>
                </div>
              </div>
            </div>
            
            {/* Account Options */}
            <div className="pt-3 border-t">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Account</h3>
              <div className="space-y-1">
                <button className="w-full flex items-center justify-between py-2 px-3 hover:bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <Shield className="h-4 w-4 text-[hsl(var(--naya-green))] mr-3" />
                    <span className="text-sm">Privacy & Security</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </button>
                
                <button className="w-full flex items-center justify-between py-2 px-3 hover:bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <CreditCard className="h-4 w-4 text-[hsl(var(--naya-green))] mr-3" />
                    <span className="text-sm">Payment Methods</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </button>
                
                <button className="w-full flex items-center justify-between py-2 px-3 hover:bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <Key className="h-4 w-4 text-[hsl(var(--naya-green))] mr-3" />
                    <span className="text-sm">Change PIN</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </button>
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-4 border-t">
            <Button variant="outline" className="w-full flex items-center justify-center text-red-500 hover:text-red-600 hover:bg-red-50 border-red-200">
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}