import { ArrowUpRight, ArrowDownLeft, Search } from "lucide-react";
import { useState } from "react";

interface Transaction {
  id: number;
  type: "sent" | "received";
  title: string;
  description: string;
  amount: string;
  date: string;
}

export default function TransactionHistory() {
  const [transactions] = useState<Transaction[]>([
    {
      id: 1,
      type: "received",
      title: "HHC Dropshippers Pvt",
      description: "Payment Received",
      amount: "+Rs.85,000",
      date: "Today, 2:35 PM"
    },
    {
      id: 2,
      type: "sent",
      title: "Facebook Ads",
      description: "Payment Sent",
      amount: "-Rs.5,000",
      date: "Today, 12:45 PM"
    },
    {
      id: 3,
      type: "received",
      title: "HHC Dropshippers Pvt",
      description: "Payment Received",
      amount: "+Rs.95,000",
      date: "Yesterday, 6:20 PM"
    },
    {
      id: 4,
      type: "sent",
      title: "Facebook Ads",
      description: "Marketing Campaign",
      amount: "-Rs.6,200",
      date: "Yesterday, 11:35 AM"
    }
  ]);
  
  const [searchTerm, setSearchTerm] = useState("");
  
  const filteredTransactions = transactions.filter(transaction => 
    transaction.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    transaction.description.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <div className="bg-white m-4 rounded-xl shadow-md overflow-hidden">
      <div className="p-4">
        <h2 className="text-[hsl(var(--naya-dark))] text-lg font-medium mb-4">Recent Transactions</h2>
        
        <div className="relative mb-4">
          <input 
            type="text" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search transactions..." 
            className="w-full py-2 pl-10 pr-4 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[hsl(var(--naya-green))] focus:border-transparent text-sm"
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
        
        <div className="space-y-2">
          {filteredTransactions.map(transaction => (
            <div key={transaction.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
              <div className="flex items-center">
                <div className={`${transaction.type === 'received' ? 'bg-green-500' : 'bg-orange-500'} h-10 w-10 rounded-full flex items-center justify-center mr-3`}>
                  {transaction.type === 'received' ? (
                    <ArrowDownLeft className="h-4 w-4 text-white" />
                  ) : (
                    <ArrowUpRight className="h-4 w-4 text-white" />
                  )}
                </div>
                <div>
                  <p className="font-medium text-[hsl(var(--naya-dark))]">{transaction.title}</p>
                  <p className="text-xs text-[hsl(var(--naya-text-gray))]">{transaction.description}</p>
                </div>
              </div>
              <div className="text-right">
                <p className={`font-medium ${transaction.type === 'received' ? 'text-green-600' : 'text-[hsl(var(--naya-dark))]'}`}>
                  {transaction.amount}
                </p>
                <p className="text-xs text-[hsl(var(--naya-text-gray))]">{transaction.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}