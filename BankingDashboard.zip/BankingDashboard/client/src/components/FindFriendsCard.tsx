import { Users } from "lucide-react";

export default function FindFriendsCard() {
  return (
    <div className="bg-white mx-4 mb-4 rounded-xl shadow-md">
      <div className="p-4">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-[hsl(var(--naya-orange-end))] font-medium">Find Your Friends</h3>
            <p className="text-[hsl(var(--naya-text-gray))] text-sm">Allow phone book syncing to find your friends on NayaPay.</p>
          </div>
          <div className="bg-[hsl(var(--naya-green))] h-12 w-12 rounded-full flex items-center justify-center relative">
            <Users className="h-6 w-6 text-white" />
            <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">3</span>
          </div>
        </div>
      </div>
    </div>
  );
}
