import { Menu, User, Headphones, Bell } from "lucide-react";
import { useState } from "react";
import NotificationCenter from "./NotificationCenter";
import UserProfile from "./UserProfile";
import { NayaPayLogo } from "@/lib/icons";

export default function Header() {
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isUserProfileOpen, setIsUserProfileOpen] = useState(false);
  
  return (
    <header className="naya-gradient text-white p-4 flex justify-between items-center">
      <button className="text-white flex items-center">
        <Menu className="h-6 w-6" />
      </button>
      
      <div className="flex items-center">
        <span className="text-2xl font-bold">NAYA</span>
        <span className="text-2xl font-bold text-white">PAY</span>
        <span className="bg-green-500 text-white text-xs rounded px-1 ml-1 flex items-center justify-center h-5">BETA</span>
      </div>
      
      <div className="flex items-center space-x-4">
        <button 
          className="text-white relative hover:opacity-90 transition-opacity"
          onClick={() => setIsUserProfileOpen(true)}
        >
          <User className="h-6 w-6" />
        </button>
        
        <button className="text-white relative hover:opacity-90 transition-opacity">
          <Headphones className="h-6 w-6" />
        </button>
        
        <div className="relative">
          <button 
            className="text-white hover:opacity-90 transition-opacity"
            onClick={() => setIsNotificationOpen(true)}
          >
            <Bell className="h-6 w-6" />
          </button>
          <span className="absolute -top-1 -right-1 bg-[hsl(var(--naya-green))] text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">1</span>
        </div>
      </div>
      
      <NotificationCenter isOpen={isNotificationOpen} setIsOpen={setIsNotificationOpen} />
      <UserProfile isOpen={isUserProfileOpen} setIsOpen={setIsUserProfileOpen} />
    </header>
  );
}
