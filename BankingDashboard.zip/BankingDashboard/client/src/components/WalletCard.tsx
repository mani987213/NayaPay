import { useState } from "react";
import { RefreshCcw, Plus, Send, SlidersHorizontal, Eye, EyeOff, QrCode } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { User, Store } from "lucide-react";

export default function WalletCard() {
  const [isBalanceHidden, setIsBalanceHidden] = useState(false);
  const [isAddMoneyOpen, setIsAddMoneyOpen] = useState(false);
  const [isSendMoneyOpen, setIsSendMoneyOpen] = useState(false);
  
  const toggleBalanceVisibility = () => {
    setIsBalanceHidden(!isBalanceHidden);
  };
  
  return (
    <div className="bg-white m-4 rounded-xl shadow-md">
      <div className="p-4">
        <div className="flex justify-between items-center">
          <h2 className="text-[hsl(var(--naya-dark))] text-lg font-medium">My Wallet</h2>
          <div className="flex items-center space-x-2">
            <button onClick={toggleBalanceVisibility} className="mr-1">
              {isBalanceHidden ? (
                <EyeOff className="h-5 w-5 text-[hsl(var(--naya-text-gray))]" />
              ) : (
                <Eye className="h-5 w-5 text-[hsl(var(--naya-text-gray))]" />
              )}
            </button>
            <button>
              <SlidersHorizontal className="h-5 w-5 text-[hsl(var(--naya-green))]" />
            </button>
          </div>
        </div>
        
        <div className="mt-2">
          {isBalanceHidden ? (
            <p className="text-3xl font-bold text-[hsl(var(--naya-dark))]">Rs. • • • • • •</p>
          ) : (
            <p className="text-3xl font-bold text-[hsl(var(--naya-dark))]">Rs.1,124,800</p>
          )}
          <div className="flex items-center text-xs text-[hsl(var(--naya-text-gray))] mt-1">
            <RefreshCcw className="h-3 w-3 mr-1" />
            <span>Last updated moments ago</span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-3 mt-4">
          <button 
            className="bg-[#00E676] text-white py-3 px-4 rounded-md flex items-center justify-center"
            onClick={() => setIsAddMoneyOpen(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            <span className="font-medium">ADD MONEY</span>
          </button>
          
          <button 
            className="bg-[#00E676] text-white py-3 px-4 rounded-md flex items-center justify-center"
            onClick={() => setIsSendMoneyOpen(true)}
          >
            <Send className="h-4 w-4 mr-2 transform rotate-0" />
            <span className="font-medium">SEND MONEY</span>
          </button>
        </div>
      </div>
      
      {/* Add Money Dialog */}
      <Dialog open={isAddMoneyOpen} onOpenChange={setIsAddMoneyOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Money to Wallet</DialogTitle>
            <DialogDescription>
              Choose a method to add money to your NayaPay wallet.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div className="flex flex-col items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
              <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="Visa" className="h-10 w-auto mb-2" />
              <span className="text-sm font-medium">Credit Card</span>
            </div>
            <div className="flex flex-col items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Mastercard_Logo.svg/1200px-Mastercard_Logo.svg.png" alt="Mastercard" className="h-10 w-auto mb-2" />
              <span className="text-sm font-medium">Debit Card</span>
            </div>
            <div className="flex flex-col items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
              <img src="https://upload.wikimedia.org/wikipedia/commons/3/3e/Easypaisa_logo.png" alt="Easypaisa" className="h-10 w-auto mb-2" />
              <span className="text-sm font-medium">Easypaisa</span>
            </div>
            <div className="flex flex-col items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
              <img src="https://upload.wikimedia.org/wikipedia/commons/4/4f/JazzCash.png" alt="JazzCash" className="h-10 w-auto mb-2" />
              <span className="text-sm font-medium">JazzCash</span>
            </div>
          </div>
          <div className="flex justify-end">
            <Button variant="outline" onClick={() => setIsAddMoneyOpen(false)}>Cancel</Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Send Money Dialog */}
      <Dialog open={isSendMoneyOpen} onOpenChange={setIsSendMoneyOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Send Money</DialogTitle>
            <DialogDescription>
              Choose how you'd like to send money.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col space-y-4 py-4">
            <div className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
              <User className="h-6 w-6 mr-3 text-[hsl(var(--naya-green))]" />
              <div>
                <p className="font-medium">Send to Contact</p>
                <p className="text-sm text-gray-500">Send money to your friends and family</p>
              </div>
            </div>
            <div className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
              <Store className="h-6 w-6 mr-3 text-[hsl(var(--naya-green))]" />
              <div>
                <p className="font-medium">Pay Merchant</p>
                <p className="text-sm text-gray-500">Pay at your favorite shops and businesses</p>
              </div>
            </div>
            <div className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
              <QrCode className="h-6 w-6 mr-3 text-[hsl(var(--naya-green))]" />
              <div>
                <p className="font-medium">Scan QR Code</p>
                <p className="text-sm text-gray-500">Scan to pay quickly and securely</p>
              </div>
            </div>
          </div>
          <div className="flex justify-end">
            <Button variant="outline" onClick={() => setIsSendMoneyOpen(false)}>Cancel</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
