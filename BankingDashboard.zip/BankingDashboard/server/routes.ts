import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  app.get('/api/wallet', (req, res) => {
    res.json({
      balance: "Rs.1,124,800",
      lastUpdated: "moments ago"
    });
  });

  app.get('/api/notifications', (req, res) => {
    res.json({
      count: 1
    });
  });

  app.get('/api/friends', (req, res) => {
    res.json({
      pendingCount: 3
    });
  });

  app.get('/api/payment-options', (req, res) => {
    res.json({
      options: [
        { id: 1, title: 'Quick Pay', icon: 'qrcode' },
        { id: 2, title: 'Pay Contact', icon: 'user' },
        { id: 3, title: 'Discover Merchants', icon: 'store' },
        { id: 4, title: 'Bills', icon: 'fileInvoice' },
        { id: 5, title: 'Bill Split', icon: 'receipt' },
        { id: 6, title: 'Chip In', icon: 'handHoldingUsd' },
        { id: 7, title: 'Gift Envelope', icon: 'envelope' },
        { id: 8, title: 'Mobile Top-Up', icon: 'mobileAlt' },
        { id: 9, title: 'StormFiber', icon: 'bolt' },
        { id: 10, title: 'Utilities', icon: 'lightbulb' },
        { id: 11, title: 'Internet and Cable', icon: 'globe' },
        { id: 12, title: 'Education', icon: 'graduationCap' }
      ]
    });
  });

  const httpServer = createServer(app);

  return httpServer;
}
